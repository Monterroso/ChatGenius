import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { io, Socket } from 'socket.io-client';
import { RootState } from '../store/store';
import { setMessages, addMessage, setActiveRoom } from '../store/slices/chatSlice';

const Chat: React.FC = () => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [message, setMessage] = useState('');
  const dispatch = useDispatch();
  const { user, token } = useSelector((state: RootState) => state.auth);
  const { messages, activeRoom } = useSelector((state: RootState) => state.chat);

  useEffect(() => {
    const newSocket = io('http://localhost:5000', {
      auth: { token },
    });

    newSocket.on('connect', () => {
      console.log('Connected to server');
    });

    newSocket.on('receive_message', (data) => {
      dispatch(addMessage(data));
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, [token, dispatch]);

  useEffect(() => {
    if (activeRoom) {
      fetchMessages();
      if (socket) {
        socket.emit('join_room', activeRoom);
      }
    }
  }, [activeRoom, socket]);

  const fetchMessages = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/messages/${activeRoom}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      if (response.ok) {
        dispatch(setMessages(data));
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && socket && activeRoom) {
      const messageData = {
        content: message,
        sender: { _id: user?.id, username: user?.username },
        room: activeRoom,
      };
      socket.emit('send_message', messageData);
      setMessage('');
    }
  };

  return (
    <div className="flex h-screen">
      <div className="w-1/4 bg-gray-800 text-white p-4">
        <h2 className="text-xl font-bold mb-4">Rooms</h2>
        <ul>
          <li
            className={`cursor-pointer p-2 ${activeRoom === 'general' ? 'bg-gray-700' : ''}`}
            onClick={() => dispatch(setActiveRoom('general'))}
          >
            General
          </li>
          <li
            className={`cursor-pointer p-2 ${activeRoom === 'random' ? 'bg-gray-700' : ''}`}
            onClick={() => dispatch(setActiveRoom('random'))}
          >
            Random
          </li>
        </ul>
      </div>
      <div className="flex-1 flex flex-col">
        <div className="flex-1 p-4 overflow-y-auto">
          {messages.map((msg) => (
            <div key={msg._id} className={`mb-2 ${msg.sender._id === user?.id ? 'text-right' : ''}`}>
              <span className="font-bold">{msg.sender.username}: </span>
              {msg.content}
            </div>
          ))}
        </div>
        <form onSubmit={sendMessage} className="p-4 border-t">
          <div className="flex">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex-1 px-3 py-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Type a message..."
            />
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              Send
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Chat;

