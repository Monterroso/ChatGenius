import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Message {
  _id: string;
  content: string;
  sender: {
    _id: string;
    username: string;
  };
  room: string;
  createdAt: string;
}

interface ChatState {
  messages: Message[];
  activeRoom: string | null;
}

const initialState: ChatState = {
  messages: [],
  activeRoom: null,
};

const chatSlice = createSlice({
  name: 'chat',
  initialState,
  reducers: {
    setMessages: (state, action: PayloadAction<Message[]>) => {
      state.messages = action.payload;
    },
    addMessage: (state, action: PayloadAction<Message>) => {
      state.messages.push(action.payload);
    },
    setActiveRoom: (state, action: PayloadAction<string>) => {
      state.activeRoom = action.payload;
    },
  },
});

export const { setMessages, addMessage, setActiveRoom } = chatSlice.actions;
export default chatSlice.reducer;

